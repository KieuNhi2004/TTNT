from collections import defaultdict



class Map:
    def __init__(self, links, locations=None, directed=False):
        pass